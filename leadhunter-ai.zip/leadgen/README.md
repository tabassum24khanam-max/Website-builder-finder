# ⚡ LeadHunter AI — Setup Guide
### Find businesses without websites in Riyadh (or any city) and generate personalized outreach messages automatically.

---

## 🚀 How to Run (Step by Step)

### STEP 1 — Install Node.js
Download and install from: https://nodejs.org
Choose the **LTS** version. Just click Next → Next → Install.

---

### STEP 2 — Open a Terminal / Command Prompt
- **Windows**: Press `Win + R`, type `cmd`, press Enter
- **Mac**: Press `Cmd + Space`, type `Terminal`, press Enter

---

### STEP 3 — Navigate to this folder
In the terminal, type:
```
cd path/to/leadgen
```
*(Replace "path/to/leadgen" with the actual folder location)*

---

### STEP 4 — Install dependencies
```
npm install
```
This downloads everything the app needs. Takes about 1 minute.

---

### STEP 5 — Install the Chrome browser (Playwright)
```
npm run install-browsers
```
This installs a controlled Chrome browser. One-time setup.

---

### STEP 6 — Add your OpenAI API Key
1. Find the file called `.env.example` in this folder
2. **Rename it** to `.env` (remove the ".example" part)
3. Open `.env` with Notepad
4. Replace `sk-paste-your-key-here` with your actual OpenAI key
5. Save the file

Your `.env` file should look like:
```
OPENAI_API_KEY=sk-abc123yourrealkeyhere
PORT=3000
```

---

### STEP 7 — Start the app
```
npm start
```

---

### STEP 8 — Open the dashboard
Open your browser and go to:
```
http://localhost:3000
```

You'll see the full dashboard! 🎉

---

## 🎮 How to Use the Dashboard

1. **Select a business category** (restaurants, salons, clinics, etc.)
2. **Set the city** (default: Riyadh)
3. **Set how many leads** you want (20, 50, or 100)
4. Click **▶ Start Scraping**
5. A Chrome browser window opens automatically — **don't close it!**
6. Watch the Live Log as businesses are scraped and AI qualifies each one
7. Go to **🔥 Hot Leads** to see the best opportunities
8. Click **View** on any lead to see the AI-generated outreach message
9. Copy the message and send it on WhatsApp/Instagram/wherever
10. Mark the lead as "Contacted" → "Replied" → "Converted"
11. Export to CSV anytime with the **⬇ Export CSV** button

---

## 💡 Tips

- **Best leads** = 🚫 No website + ⭐ Score 7+ (go straight to Hot Leads tab)
- The AI reads Google reviews to find businesses where customers mention needing an online presence
- You can edit the outreach message before copying it — make it personal!
- Click "🔄 Regenerate" to get a fresh AI-written message if you don't like the first one
- Run different categories one at a time (restaurants first, then clinics, etc.)

---

## 💰 Cost Estimate

| Item | Cost |
|---|---|
| Node.js + Playwright | Free |
| Google Maps scraping | Free |
| OpenAI GPT-4o-mini per lead | ~$0.002 (0.2 cents) |
| 50 leads qualified | ~$0.10 total |
| 200 leads qualified | ~$0.40 total |

The OpenAI cost is essentially nothing.

---

## ❓ Troubleshooting

**"OpenAI API key not configured"**
→ Make sure you renamed `.env.example` to `.env` and added your key

**"npm is not recognized"**
→ Node.js is not installed. Go back to Step 1.

**Browser opens but shows no results**
→ Google Maps may have changed layout. Try a different search category.

**App crashed**
→ Close the terminal, open it again, and run `npm start` again

---

## 🔮 Future Features (coming later)
- WhatsApp Web automation (auto-send messages)
- Instagram DM automation
- Arabic message generation
- LinkedIn scraping
- Scheduled daily scraping
